class Null_Parser():
    def parse_textfile(self, textfile):
        return textfile
